<?php
/**
 * Snax Post Overview Template Part
 *
 * @package snax 1.11
 * @subpackage Theme
 */
