<div class="snax-poll-progress">
	<div class="snax-poll-progress-track">
		<div class="snax-poll-progress-bar" style="width: <?php echo (float) snax_get_poll_percentage_result( 9 ); ?>%">
			<div class="snax-poll-progress-value"><?php printf( esc_html__( '%.0f%%', 'snax' ), snax_get_poll_percentage_result( 9 ) ); ?></div>
		</div>
	</div>
</div>