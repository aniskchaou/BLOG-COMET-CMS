<?php

class YZ_Phone_Info_Box extends YZ_Info_Box {

}