<?php

class YZ_User_Badges {

    /**
     * # Widget Content.
     */
    function widget() {
        do_action( 'yz_user_badges_widget_content' );
    }

}